<?php

$servidor = "localhost";
$usuario = "iaqui";
$senha = "aqui";
$dbname = "aqui";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

?>